﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3a
{
    internal class Program
    {
        static void Main(string[] args)
        {//Задание 3a
            Console.Title = "Расстояние между точками";
            Console.Write("Введите координаты первой точки x1=");
            float x1 = float.Parse(Console.ReadLine());
            Console.Write("y1=");
            float y1 = float.Parse(Console.ReadLine());
            Console.Write("Введите координаты второй точки,x2=");
            float x2 = float.Parse(Console.ReadLine());
            Console.Write("y2=");
            float y2 = float.Parse(Console.ReadLine());

            double r = Math.Sqrt(Math.Pow((x2 - x1), 2) + Math.Pow((y2 - y1), 2));
            Console.WriteLine("Расстояние между точками {0:F2}", r);
            Console.ReadLine();
        }
    }
}
