﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4a
{
    internal class Program
    {
        static void Main(string[] args)
        {//Задание 4а
            int a = 15;     
            int b = 35;     
            int с = a;      
            a = b;          
            b = с;
            Console.WriteLine("a=" + a + " , b=" + b);
            Console.ReadLine();

        }
    }
}
