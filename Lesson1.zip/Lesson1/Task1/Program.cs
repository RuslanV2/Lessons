﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            Console.Title = "Анкета";
            Console.Write("Имя: ");
            string name1 = Console.ReadLine();
            Console.Clear();
            Console.Write("Фамилия: ");
            string name2 = Console.ReadLine();
            Console.Clear();
            Console.Write("Возраст: ");
            string let = Console.ReadLine();
            Console.Clear();
            Console.Write("Рост: ");
            string h = Console.ReadLine();
            Console.Clear();
            Console.Write("Вес: ");
            string m = Console.ReadLine();
            Console.Clear();

            Console.WriteLine(name1 + " " + name2 + ", возраст: " + let + ", рост: " + h + ", вес: " + m);
            Console.WriteLine("{0} {1}, возраст: {2}, рост: {3}, вес: {4}", name1, name2, let, h, m);
            Console.WriteLine($"{name1} {name2}, возраст: {let}, рост: {h}, вес: {m}");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
