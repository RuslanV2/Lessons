﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4b
{
    internal class Program
    {
        static void Main(string[] args)
        {//Задание 4b
            int a = 15;
            int b = 35;
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine("a="+a+" , b="+b);
            Console.ReadLine();
        }
    }
}
